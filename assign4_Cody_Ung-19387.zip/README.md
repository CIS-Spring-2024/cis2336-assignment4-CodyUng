How to run:
1. Clone the repository
2. Have Node.js and express installed
3. Enter the OrderForm folder and run the terminal in that path
4. Enter into the terminal node server1.js, to host the file locally
5. Enter into any browser this URL : http://localhost:3000, to access the website
